
  # Forex Prop Firm Website

  This is a code bundle for Forex Prop Firm Website. The original project is available at https://www.figma.com/design/cTJWtanD1OIFdDatnDuiNF/Forex-Prop-Firm-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  