/**
 * API Service Layer
 * 
 * This file contains all API calls to your Node.js backend.
 * Replace the mock implementations with actual fetch calls to your server.
 * 
 * Base URL configuration:
 * - Development: http://localhost:3000/api
 * - Production: https://your-domain.com/api
 */

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

// Helper function for making API calls
async function apiCall(endpoint: string, options: RequestInit = {}) {
  const token = localStorage.getItem('authToken');
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
    });
    
    if (!response.ok) {
      throw new Error(`API Error: ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('API call failed:', error);
    throw error;
  }
}

// ============================================
// AUTHENTICATION APIs
// ============================================

export async function loginUser(email: string, password: string) {
  // TODO: Replace with actual API call
  // return apiCall('/auth/login', {
  //   method: 'POST',
  //   body: JSON.stringify({ email, password }),
  // });
  
  // MOCK IMPLEMENTATION
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        token: 'mock-jwt-token-' + Date.now(),
        user: {
          id: '1',
          email,
          name: 'Adebayo Johnson',
          phone: '+234 803 123 4567',
        }
      });
    }, 1000);
  });
}

export async function registerUser(data: {
  email: string;
  password: string;
  name: string;
  phone: string;
}) {
  // TODO: Replace with actual API call
  // return apiCall('/auth/register', {
  //   method: 'POST',
  //   body: JSON.stringify(data),
  // });
  
  // MOCK IMPLEMENTATION
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        message: 'Registration successful',
        user: {
          id: Date.now().toString(),
          ...data,
        }
      });
    }, 1000);
  });
}

export async function forgotPassword(email: string) {
  // TODO: Replace with actual API call
  // return apiCall('/auth/forgot-password', {
  //   method: 'POST',
  //   body: JSON.stringify({ email }),
  // });
  
  // MOCK IMPLEMENTATION
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        message: 'Password reset link sent to your email',
      });
    }, 1000);
  });
}

export async function resetPassword(token: string, newPassword: string) {
  // TODO: Replace with actual API call
  // return apiCall('/auth/reset-password', {
  //   method: 'POST',
  //   body: JSON.stringify({ token, newPassword }),
  // });
  
  // MOCK IMPLEMENTATION
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        message: 'Password reset successful',
      });
    }, 1000);
  });
}

// ============================================
// USER PROFILE APIs
// ============================================

export async function getUserProfile() {
  // TODO: Replace with actual API call
  // return apiCall('/user/profile');
  
  // MOCK IMPLEMENTATION
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        id: '1',
        name: 'Adebayo Johnson',
        email: 'adebayo@example.com',
        phone: '+234 803 123 4567',
        avatar: null,
        joinedDate: '2024-01-15',
        kycStatus: 'verified',
      });
    }, 500);
  });
}

export async function updateUserProfile(data: any) {
  // TODO: Replace with actual API call
  // return apiCall('/user/profile', {
  //   method: 'PUT',
  //   body: JSON.stringify(data),
  // });
  
  // MOCK IMPLEMENTATION
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        message: 'Profile updated successfully',
      });
    }, 1000);
  });
}

// ============================================
// CHALLENGE APIs
// ============================================

export async function getActiveChallenges() {
  // TODO: Replace with actual API call
  // return apiCall('/challenges/active');
  
  // MOCK IMPLEMENTATION - Returns from mockData
  const { getActiveChallengesMock } = await import('../data/mockData');
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(getActiveChallengesMock());
    }, 500);
  });
}

export async function getChallengeHistory() {
  // TODO: Replace with actual API call
  // return apiCall('/challenges/history');
  
  // MOCK IMPLEMENTATION
  const { getChallengeHistoryMock } = await import('../data/mockData');
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(getChallengeHistoryMock());
    }, 500);
  });
}

export async function getChallengeById(id: string) {
  // TODO: Replace with actual API call
  // return apiCall(`/challenges/${id}`);
  
  // MOCK IMPLEMENTATION
  const challenges = await getActiveChallenges();
  return challenges.find((c: any) => c.id === id);
}

export async function purchaseChallenge(data: {
  accountType: 'naira' | 'dollar';
  size: string;
  paymentMethod: string;
}) {
  // TODO: Replace with actual API call
  // return apiCall('/challenges/purchase', {
  //   method: 'POST',
  //   body: JSON.stringify(data),
  // });
  
  // MOCK IMPLEMENTATION
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        challenge_id: 'CH' + Date.now(),
        payment_url: 'https://paystack.com/pay/mock-payment',
        message: 'Challenge purchase initiated',
      });
    }, 1000);
  });
}

// ============================================
// PAYOUT APIs
// ============================================

export async function getPayouts() {
  // TODO: Replace with actual API call
  // return apiCall('/payouts');
  
  // MOCK IMPLEMENTATION
  const { getPayoutsMock } = await import('../data/mockData');
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(getPayoutsMock());
    }, 500);
  });
}

export async function requestPayout(data: {
  challengeId: string;
  amount: number;
  bankDetails: {
    accountName: string;
    accountNumber: string;
    bankName: string;
  };
}) {
  // TODO: Replace with actual API call
  // return apiCall('/payouts/request', {
  //   method: 'POST',
  //   body: JSON.stringify(data),
  // });
  
  // MOCK IMPLEMENTATION
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        payout_id: 'PO' + Date.now(),
        message: 'Payout request submitted successfully',
      });
    }, 1000);
  });
}

// ============================================
// SUPPORT TICKET APIs
// ============================================

export async function getSupportTickets() {
  // TODO: Replace with actual API call
  // return apiCall('/support/tickets');
  
  // MOCK IMPLEMENTATION
  const { getSupportTicketsMock } = await import('../data/mockData');
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(getSupportTicketsMock());
    }, 500);
  });
}

export async function createSupportTicket(data: {
  subject: string;
  category: string;
  message: string;
  priority: string;
}) {
  // TODO: Replace with actual API call
  // return apiCall('/support/tickets', {
  //   method: 'POST',
  //   body: JSON.stringify(data),
  // });
  
  // MOCK IMPLEMENTATION
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        ticket_id: 'TK' + Date.now(),
        message: 'Support ticket created successfully',
      });
    }, 1000);
  });
}

export async function getTicketMessages(ticketId: string) {
  // TODO: Replace with actual API call
  // return apiCall(`/support/tickets/${ticketId}/messages`);
  
  // MOCK IMPLEMENTATION
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        {
          id: '1',
          sender: 'user',
          message: 'I need help with my challenge',
          timestamp: '2024-02-20T10:00:00Z',
        },
        {
          id: '2',
          sender: 'support',
          message: 'Hello! How can we assist you today?',
          timestamp: '2024-02-20T10:05:00Z',
        },
      ]);
    }, 500);
  });
}

export async function replyToTicket(ticketId: string, message: string) {
  // TODO: Replace with actual API call
  // return apiCall(`/support/tickets/${ticketId}/reply`, {
  //   method: 'POST',
  //   body: JSON.stringify({ message }),
  // });
  
  // MOCK IMPLEMENTATION
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        message: 'Reply sent successfully',
      });
    }, 1000);
  });
}

// ============================================
// CONTACT FORM API
// ============================================

export async function submitContactForm(data: {
  name: string;
  email: string;
  phone?: string;
  subject: string;
  message: string;
}) {
  // TODO: Replace with actual API call
  // return apiCall('/contact', {
  //   method: 'POST',
  //   body: JSON.stringify(data),
  // });
  
  // MOCK IMPLEMENTATION
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        message: 'Thank you for contacting us. We will get back to you soon!',
      });
    }, 1000);
  });
}

// ============================================
// DASHBOARD STATS API
// ============================================

export async function getDashboardStats() {
  // TODO: Replace with actual API call
  // return apiCall('/dashboard/stats');
  
  // MOCK IMPLEMENTATION
  const { getDashboardStatsMock } = await import('../data/mockData');
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(getDashboardStatsMock());
    }, 500);
  });
}

// ============================================
// TRADING ACTIVITY API
// ============================================

export async function getTradingActivity(challengeId: string) {
  // TODO: Replace with actual API call
  // return apiCall(`/challenges/${challengeId}/trades`);
  
  // MOCK IMPLEMENTATION
  const { getTradingActivityMock } = await import('../data/mockData');
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(getTradingActivityMock());
    }, 500);
  });
}
