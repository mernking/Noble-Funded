import { createBrowserRouter, Navigate } from 'react-router';
import PublicLayout from './pages/PublicLayout';
import HomePage from './pages/HomePage';
import PricingPage from './pages/PricingPage';
import HowItWorksPage from './pages/HowItWorksPage';
import FAQPage from './pages/FAQPage';
import ContactPage from './pages/ContactPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardLayout from './pages/dashboard/DashboardLayout';
import DashboardOverview from './pages/dashboard/DashboardOverview';
import ActiveChallengesPage from './pages/dashboard/ActiveChallengesPage';
import ChallengeHistoryPage from './pages/dashboard/ChallengeHistoryPage';
import PayoutsPage from './pages/dashboard/PayoutsPage';
import SupportPage from './pages/dashboard/SupportPage';
import SettingsPage from './pages/dashboard/SettingsPage';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <PublicLayout />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'pricing', element: <PricingPage /> },
      { path: 'how-it-works', element: <HowItWorksPage /> },
      { path: 'faq', element: <FAQPage /> },
      { path: 'contact', element: <ContactPage /> },
    ],
  },
  {
    path: '/login',
    element: <LoginPage />,
  },
  {
    path: '/register',
    element: <RegisterPage />,
  },
  {
    path: '/dashboard',
    element: <DashboardLayout />,
    children: [
      { index: true, element: <DashboardOverview /> },
      { path: 'challenges', element: <ActiveChallengesPage /> },
      { path: 'challenges/:id', element: <ActiveChallengesPage /> },
      { path: 'history', element: <ChallengeHistoryPage /> },
      { path: 'payouts', element: <PayoutsPage /> },
      { path: 'support', element: <SupportPage /> },
      { path: 'settings', element: <SettingsPage /> },
    ],
  },
  {
    path: '*',
    element: <Navigate to="/" replace />,
  },
]);
