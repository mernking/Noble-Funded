/**
 * Mock Data for Demo Purposes
 * This file contains all the demo data used in the application
 */

export interface Challenge {
  id: string;
  accountType: 'naira' | 'dollar';
  accountSize: number;
  currency: '₦' | '$';
  status: 'active' | 'passed' | 'failed' | 'pending';
  startDate: string;
  endDate?: string;
  daysRemaining: number;
  totalDays: number;
  startingBalance: number;
  currentBalance: number;
  currentEquity: number;
  profit: number;
  profitPercentage: number;
  targetBalance: number;
  targetPercentage: number;
  maxDrawdown: number;
  maxDrawdownLimit: number;
  dailyLoss: number;
  dailyLossLimit: number;
  mt5Login: string;
  mt5Server: string;
  mt5Password: string;
  phase: 'Phase 1' | 'Phase 2' | 'Funded';
}

export interface TradeHistory {
  id: string;
  symbol: string;
  type: 'buy' | 'sell';
  lotSize: number;
  openPrice: number;
  closePrice: number;
  profit: number;
  openTime: string;
  closeTime: string;
  duration: string;
}

export interface Payout {
  id: string;
  challengeId: string;
  amount: number;
  currency: '₦' | '$';
  status: 'pending' | 'approved' | 'rejected' | 'paid';
  requestDate: string;
  paidDate?: string;
  notes?: string;
  bankDetails?: {
    accountName: string;
    accountNumber: string;
    bankName: string;
  };
}

export interface SupportTicket {
  id: string;
  subject: string;
  category: string;
  priority: 'low' | 'medium' | 'high';
  status: 'open' | 'in-progress' | 'resolved' | 'closed';
  createdDate: string;
  lastUpdated: string;
  messages: number;
}

// ============================================
// ACTIVE CHALLENGES MOCK DATA
// ============================================

export function getActiveChallengesMock(): Challenge[] {
  return [
    {
      id: 'CH12345',
      accountType: 'naira',
      accountSize: 200000,
      currency: '₦',
      status: 'active',
      startDate: '2024-02-01',
      daysRemaining: 23,
      totalDays: 60,
      startingBalance: 200000,
      currentBalance: 286000,
      currentEquity: 289450,
      profit: 86000,
      profitPercentage: 43,
      targetBalance: 400000,
      targetPercentage: 100,
      maxDrawdown: 3.2,
      maxDrawdownLimit: 10,
      dailyLoss: 1.5,
      dailyLossLimit: 3,
      mt5Login: '87654321',
      mt5Server: 'NobleFunded-Demo',
      mt5Password: 'Trader@2024',
      phase: 'Phase 1',
    },
    {
      id: 'CH12346',
      accountType: 'dollar',
      accountSize: 5000,
      currency: '$',
      status: 'active',
      startDate: '2024-02-10',
      daysRemaining: 32,
      totalDays: 60,
      startingBalance: 5000,
      currentBalance: 5850,
      currentEquity: 5920,
      profit: 850,
      profitPercentage: 17,
      targetBalance: 10000,
      targetPercentage: 100,
      maxDrawdown: 2.8,
      maxDrawdownLimit: 10,
      dailyLoss: 0.9,
      dailyLossLimit: 3,
      mt5Login: '87654322',
      mt5Server: 'NobleFunded-Demo',
      mt5Password: 'Trader@2024',
      phase: 'Phase 1',
    },
  ];
}

// ============================================
// CHALLENGE HISTORY MOCK DATA
// ============================================

export function getChallengeHistoryMock(): Challenge[] {
  return [
    ...getActiveChallengesMock(),
    {
      id: 'CH12340',
      accountType: 'naira',
      accountSize: 100000,
      currency: '₦',
      status: 'passed',
      startDate: '2024-01-01',
      endDate: '2024-01-28',
      daysRemaining: 0,
      totalDays: 60,
      startingBalance: 100000,
      currentBalance: 210000,
      currentEquity: 210000,
      profit: 110000,
      profitPercentage: 110,
      targetBalance: 200000,
      targetPercentage: 100,
      maxDrawdown: 4.5,
      maxDrawdownLimit: 10,
      dailyLoss: 1.2,
      dailyLossLimit: 3,
      mt5Login: '87654320',
      mt5Server: 'NobleFunded-Demo',
      mt5Password: 'Trader@2024',
      phase: 'Phase 1',
    },
    {
      id: 'CH12338',
      accountType: 'naira',
      accountSize: 50000,
      currency: '₦',
      status: 'failed',
      startDate: '2023-12-15',
      endDate: '2023-12-22',
      daysRemaining: 0,
      totalDays: 60,
      startingBalance: 50000,
      currentBalance: 44500,
      currentEquity: 44500,
      profit: -5500,
      profitPercentage: -11,
      targetBalance: 100000,
      targetPercentage: 100,
      maxDrawdown: 11.2,
      maxDrawdownLimit: 10,
      dailyLoss: 2.5,
      dailyLossLimit: 3,
      mt5Login: '87654318',
      mt5Server: 'NobleFunded-Demo',
      mt5Password: 'Trader@2024',
      phase: 'Phase 1',
    },
  ];
}

// ============================================
// TRADING ACTIVITY MOCK DATA
// ============================================

export function getTradingActivityMock(): TradeHistory[] {
  return [
    {
      id: 'T1001',
      symbol: 'GBPUSD',
      type: 'buy',
      lotSize: 0.5,
      openPrice: 1.2650,
      closePrice: 1.2685,
      profit: 17500,
      openTime: '2024-02-24T08:30:00Z',
      closeTime: '2024-02-24T14:20:00Z',
      duration: '5h 50m',
    },
    {
      id: 'T1002',
      symbol: 'EURUSD',
      type: 'sell',
      lotSize: 0.3,
      openPrice: 1.0820,
      closePrice: 1.0805,
      profit: 4500,
      openTime: '2024-02-23T10:15:00Z',
      closeTime: '2024-02-23T16:45:00Z',
      duration: '6h 30m',
    },
    {
      id: 'T1003',
      symbol: 'USDJPY',
      type: 'buy',
      lotSize: 0.4,
      openPrice: 149.80,
      closePrice: 150.20,
      profit: 16000,
      openTime: '2024-02-22T07:00:00Z',
      closeTime: '2024-02-22T18:30:00Z',
      duration: '11h 30m',
    },
    {
      id: 'T1004',
      symbol: 'XAUUSD',
      type: 'buy',
      lotSize: 0.2,
      openPrice: 2025.50,
      closePrice: 2018.30,
      profit: -14400,
      openTime: '2024-02-21T09:00:00Z',
      closeTime: '2024-02-21T12:15:00Z',
      duration: '3h 15m',
    },
    {
      id: 'T1005',
      symbol: 'GBPJPY',
      type: 'sell',
      lotSize: 0.3,
      openPrice: 189.45,
      closePrice: 188.90,
      profit: 16500,
      openTime: '2024-02-20T11:30:00Z',
      closeTime: '2024-02-20T15:00:00Z',
      duration: '3h 30m',
    },
  ];
}

// ============================================
// PAYOUTS MOCK DATA
// ============================================

export function getPayoutsMock(): Payout[] {
  return [
    {
      id: 'PO001',
      challengeId: 'CH12340',
      amount: 88000,
      currency: '₦',
      status: 'paid',
      requestDate: '2024-02-01',
      paidDate: '2024-02-05',
      notes: 'First payout - 80% profit share',
      bankDetails: {
        accountName: 'Adebayo Johnson',
        accountNumber: '0123456789',
        bankName: 'GTBank',
      },
    },
    {
      id: 'PO002',
      challengeId: 'CH12345',
      amount: 68800,
      currency: '₦',
      status: 'pending',
      requestDate: '2024-02-20',
      notes: 'Pending approval',
      bankDetails: {
        accountName: 'Adebayo Johnson',
        accountNumber: '0123456789',
        bankName: 'GTBank',
      },
    },
  ];
}

// ============================================
// SUPPORT TICKETS MOCK DATA
// ============================================

export function getSupportTicketsMock(): SupportTicket[] {
  return [
    {
      id: 'TK001',
      subject: 'Question about profit split',
      category: 'General Inquiry',
      priority: 'medium',
      status: 'resolved',
      createdDate: '2024-02-15',
      lastUpdated: '2024-02-16',
      messages: 4,
    },
    {
      id: 'TK002',
      subject: 'MT5 login credentials not working',
      category: 'Technical Support',
      priority: 'high',
      status: 'open',
      createdDate: '2024-02-20',
      lastUpdated: '2024-02-20',
      messages: 2,
    },
    {
      id: 'TK003',
      subject: 'Payout request status',
      category: 'Billing',
      priority: 'medium',
      status: 'in-progress',
      createdDate: '2024-02-18',
      lastUpdated: '2024-02-19',
      messages: 5,
    },
  ];
}

// ============================================
// DASHBOARD STATS MOCK DATA
// ============================================

export function getDashboardStatsMock() {
  return {
    activeChallenges: 2,
    totalProfit: 936000, // ₦86,000 + $850 (converted)
    totalProfitFormatted: '₦936,000',
    upcomingPayouts: 1,
    passRate: 75,
    recentActivity: [
      {
        id: '1',
        type: 'trade',
        description: 'Closed GBPUSD trade with ₦17,500 profit',
        timestamp: '2 hours ago',
      },
      {
        id: '2',
        type: 'payout',
        description: 'Payout request submitted for ₦68,800',
        timestamp: '5 days ago',
      },
      {
        id: '3',
        type: 'challenge',
        description: 'New Dollar $5,000 challenge started',
        timestamp: '15 days ago',
      },
      {
        id: '4',
        type: 'achievement',
        description: 'Passed Phase 1 of ₦100,000 challenge',
        timestamp: '28 days ago',
      },
    ],
  };
}

// ============================================
// PRICING DATA
// ============================================

export interface PricingTier {
  name: string;
  accountSize: string;
  price: string;
  features: string[];
  popular?: boolean;
}

export function getNairaPricingTiers(): PricingTier[] {
  return [
    {
      name: 'Starter',
      accountSize: '₦50,000',
      price: '₦12,000',
      features: [
        'Target: ₦100,000 (100% gain)',
        '10% Max Drawdown',
        '3% Daily Loss Limit',
        '60 Days to reach target',
        'Unlimited trading days',
        '80% Profit Split',
        'Free MT5 Platform',
      ],
    },
    {
      name: 'Standard',
      accountSize: '₦100,000',
      price: '₦22,000',
      features: [
        'Target: ₦200,000 (100% gain)',
        '10% Max Drawdown',
        '3% Daily Loss Limit',
        '60 Days to reach target',
        'Unlimited trading days',
        '80% Profit Split',
        'Free MT5 Platform',
      ],
      popular: true,
    },
    {
      name: 'Professional',
      accountSize: '₦200,000',
      price: '₦40,000',
      features: [
        'Target: ₦400,000 (100% gain)',
        '10% Max Drawdown',
        '3% Daily Loss Limit',
        '60 Days to reach target',
        'Unlimited trading days',
        '80% Profit Split',
        'Free MT5 Platform',
      ],
    },
    {
      name: 'Elite',
      accountSize: '₦500,000',
      price: '₦95,000',
      features: [
        'Target: ₦1,000,000 (100% gain)',
        '10% Max Drawdown',
        '3% Daily Loss Limit',
        '60 Days to reach target',
        'Unlimited trading days',
        '80% Profit Split',
        'Free MT5 Platform',
      ],
    },
  ];
}

export function getDollarPricingTiers(): PricingTier[] {
  return [
    {
      name: 'Starter',
      accountSize: '$5,000',
      price: '$50',
      features: [
        'Target: $10,000 (100% gain)',
        '10% Max Drawdown',
        '3% Daily Loss Limit',
        '60 Days to reach target',
        'Unlimited trading days',
        '80% Profit Split',
        'Free MT5 Platform',
      ],
    },
    {
      name: 'Standard',
      accountSize: '$10,000',
      price: '$90',
      features: [
        'Target: $20,000 (100% gain)',
        '10% Max Drawdown',
        '3% Daily Loss Limit',
        '60 Days to reach target',
        'Unlimited trading days',
        '80% Profit Split',
        'Free MT5 Platform',
      ],
      popular: true,
    },
    {
      name: 'Professional',
      accountSize: '$25,000',
      price: '$200',
      features: [
        'Target: $50,000 (100% gain)',
        '10% Max Drawdown',
        '3% Daily Loss Limit',
        '60 Days to reach target',
        'Unlimited trading days',
        '80% Profit Split',
        'Free MT5 Platform',
      ],
    },
    {
      name: 'Elite',
      accountSize: '$50,000',
      price: '$375',
      features: [
        'Target: $100,000 (100% gain)',
        '10% Max Drawdown',
        '3% Daily Loss Limit',
        '60 Days to reach target',
        'Unlimited trading days',
        '80% Profit Split',
        'Free MT5 Platform',
      ],
    },
  ];
}

// ============================================
// FAQ DATA
// ============================================

export interface FAQItem {
  id: string;
  category: string;
  question: string;
  answer: string;
}

export function getFAQData(): FAQItem[] {
  return [
    {
      id: 'faq-1',
      category: 'Getting Started',
      question: 'What is Noble Funded?',
      answer: 'Noble Funded is a Nigerian proprietary trading firm that provides capital to skilled forex traders. We offer both Naira and Dollar denominated trading accounts, allowing you to trade with our capital while keeping up to 80% of the profits you generate.',
    },
    {
      id: 'faq-2',
      category: 'Getting Started',
      question: 'How do I get started?',
      answer: 'Getting started is simple: 1) Register for a free account, 2) Choose your preferred challenge size (Naira or Dollar), 3) Pay the one-time challenge fee, 4) Receive your MT5 credentials, and 5) Start trading immediately!',
    },
    {
      id: 'faq-3',
      category: 'Challenge Rules',
      question: 'What are the challenge rules?',
      answer: 'All challenges have the following rules: 100% profit target, 10% maximum drawdown, 3% daily loss limit, and 60 days to reach your target. There are no minimum trading days required, giving you complete flexibility.',
    },
    {
      id: 'faq-4',
      category: 'Challenge Rules',
      question: 'What happens if I break a rule?',
      answer: 'If you breach the maximum drawdown (10%) or daily loss limit (3%), your challenge will be terminated immediately. However, you can always purchase a new challenge and try again.',
    },
    {
      id: 'faq-5',
      category: 'Payouts',
      question: 'How do payouts work?',
      answer: 'Once you pass your challenge and reach the profit target, you can request a payout. You keep 80% of the profits, and we keep 20%. Payouts are processed within 3-5 business days to your Nigerian bank account.',
    },
    {
      id: 'faq-6',
      category: 'Payouts',
      question: 'What payment methods do you accept?',
      answer: 'We accept payments via Paystack, which supports all major Nigerian banks, USSD, and card payments. For Dollar accounts, we also accept international card payments.',
    },
    {
      id: 'faq-7',
      category: 'Account Types',
      question: 'What is the difference between Naira and Dollar accounts?',
      answer: 'Naira accounts are denominated in Nigerian Naira (₦) and are perfect for local traders who want to avoid currency conversion fees. Dollar accounts ($) are denominated in USD and are ideal for those who prefer trading in the global reserve currency.',
    },
    {
      id: 'faq-8',
      category: 'Account Types',
      question: 'Can I have multiple challenges at the same time?',
      answer: 'Yes! You can run multiple challenges simultaneously. Many of our successful traders manage 2-3 accounts at once to maximize their profit potential.',
    },
    {
      id: 'faq-9',
      category: 'Trading',
      question: 'What can I trade?',
      answer: 'You can trade all major forex pairs (EUR/USD, GBP/USD, USD/JPY, etc.), as well as gold, silver, and major indices. All trading is done on the MetaTrader 5 (MT5) platform.',
    },
    {
      id: 'faq-10',
      category: 'Trading',
      question: 'Can I use Expert Advisors (EAs)?',
      answer: 'Yes, you are allowed to use Expert Advisors and automated trading strategies. However, all trades must comply with our challenge rules.',
    },
    {
      id: 'faq-11',
      category: 'Trading',
      question: 'Are there any restricted trading times?',
      answer: 'No, you can trade 24/5 during forex market hours. There are no restrictions on trading during news events or specific times of the day.',
    },
    {
      id: 'faq-12',
      category: 'Support',
      question: 'How can I contact support?',
      answer: 'You can reach our support team via email at contact@noblefunded.com, WhatsApp at +234 XXX XXX XXXX, or by creating a support ticket in your dashboard. We typically respond within 24 hours.',
    },
  ];
}

// ============================================
// TESTIMONIALS DATA
// ============================================

export interface Testimonial {
  id: string;
  name: string;
  location: string;
  avatar?: string;
  rating: number;
  text: string;
  achievement: string;
}

export function getTestimonialsData(): Testimonial[] {
  return [
    {
      id: 't1',
      name: 'Chukwuemeka Okonkwo',
      location: 'Lagos, Nigeria',
      rating: 5,
      text: 'Noble Funded gave me the opportunity I needed. I passed my ₦200,000 challenge in just 3 weeks and received my first payout of ₦160,000. The platform is transparent and the support team is excellent!',
      achievement: 'Funded Trader - ₦200,000',
    },
    {
      id: 't2',
      name: 'Aisha Mohammed',
      location: 'Abuja, Nigeria',
      rating: 5,
      text: 'As a woman in trading, finding a Nigerian prop firm that treats everyone fairly was important to me. Noble Funded delivers on their promises. I\'ve earned over ₦500,000 in the last 3 months!',
      achievement: 'Funded Trader - ₦500,000',
    },
    {
      id: 't3',
      name: 'Ibrahim Yusuf',
      location: 'Kano, Nigeria',
      rating: 5,
      text: 'The Naira account option is a game changer. No more worrying about dollar conversion rates. I can focus purely on trading. Passed my challenge on the first attempt!',
      achievement: 'Funded Trader - ₦100,000',
    },
    {
      id: 't4',
      name: 'Ngozi Eze',
      location: 'Port Harcourt, Nigeria',
      rating: 5,
      text: 'Best prop firm in Nigeria! Fast payouts, clear rules, and great customer service. I recommend Noble Funded to all serious traders.',
      achievement: 'Funded Trader - $10,000',
    },
  ];
}
