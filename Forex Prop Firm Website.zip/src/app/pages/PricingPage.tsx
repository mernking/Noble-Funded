import { Link } from 'react-router';
import { CheckCircle, X } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { getNairaPricingTiers, getDollarPricingTiers } from '../data/mockData';

export default function PricingPage() {
  const nairaPlans = getNairaPricingTiers();
  const dollarPlans = getDollarPricingTiers();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-gradient-to-br from-emerald-600 to-green-700 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Simple, Transparent Pricing</h1>
          <p className="text-xl text-emerald-50 max-w-2xl mx-auto">
            One-time fee. No hidden charges. Keep 80% of all profits.
          </p>
        </div>
      </section>

      {/* Pricing Tables */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Tabs defaultValue="naira" className="max-w-7xl mx-auto">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-12">
              <TabsTrigger value="naira" className="text-lg">Naira Accounts (₦)</TabsTrigger>
              <TabsTrigger value="dollar" className="text-lg">Dollar Accounts ($)</TabsTrigger>
            </TabsList>

            <TabsContent value="naira">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                {nairaPlans.map((plan) => (
                  <Card key={plan.name} className={`relative ${plan.popular ? 'border-2 border-emerald-500 shadow-xl scale-105' : 'border border-gray-200'}`}>
                    {plan.popular && (
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                        <span className="bg-emerald-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                          Most Popular
                        </span>
                      </div>
                    )}
                    <CardHeader>
                      <CardTitle className="text-2xl">{plan.name}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div>
                        <div className="text-4xl font-bold text-emerald-600">{plan.accountSize}</div>
                        <div className="text-gray-600">Account Size</div>
                      </div>
                      <div>
                        <div className="text-3xl font-bold">{plan.price}</div>
                        <div className="text-sm text-gray-600">One-time challenge fee</div>
                      </div>
                      <ul className="space-y-3">
                        {plan.features.map((feature, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                            <span className="text-gray-700">{feature}</span>
                          </li>
                        ))}
                      </ul>
                      <Button asChild className="w-full bg-emerald-600 hover:bg-emerald-700" size="lg">
                        <Link to="/register">Buy Challenge</Link>
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="dollar">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                {dollarPlans.map((plan) => (
                  <Card key={plan.name} className={`relative ${plan.popular ? 'border-2 border-blue-500 shadow-xl scale-105' : 'border border-gray-200'}`}>
                    {plan.popular && (
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                        <span className="bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                          Most Popular
                        </span>
                      </div>
                    )}
                    <CardHeader>
                      <CardTitle className="text-2xl">{plan.name}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div>
                        <div className="text-4xl font-bold text-blue-600">{plan.accountSize}</div>
                        <div className="text-gray-600">Account Size</div>
                      </div>
                      <div>
                        <div className="text-3xl font-bold">{plan.price}</div>
                        <div className="text-sm text-gray-600">One-time challenge fee</div>
                      </div>
                      <ul className="space-y-3">
                        {plan.features.map((feature, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <CheckCircle className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
                            <span className="text-gray-700">{feature}</span>
                          </li>
                        ))}
                      </ul>
                      <Button asChild className="w-full bg-blue-600 hover:bg-blue-700" size="lg">
                        <Link to="/register">Buy Challenge</Link>
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Rules Comparison */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-5xl">
          <h2 className="text-3xl font-bold text-center mb-12">Challenge Rules</h2>
          
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-gray-100">
                  <th className="p-4 text-left font-bold border">Rule</th>
                  <th className="p-4 text-center font-bold border">Phase 1</th>
                  <th className="p-4 text-center font-bold border">Phase 2 (Optional)</th>
                  <th className="p-4 text-center font-bold border">Funded</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="p-4 border font-semibold">Profit Target</td>
                  <td className="p-4 border text-center">100%</td>
                  <td className="p-4 border text-center">50%</td>
                  <td className="p-4 border text-center">No Target</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="p-4 border font-semibold">Max Drawdown</td>
                  <td className="p-4 border text-center">10%</td>
                  <td className="p-4 border text-center">10%</td>
                  <td className="p-4 border text-center">10%</td>
                </tr>
                <tr>
                  <td className="p-4 border font-semibold">Daily Loss Limit</td>
                  <td className="p-4 border text-center">3%</td>
                  <td className="p-4 border text-center">3%</td>
                  <td className="p-4 border text-center">3%</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="p-4 border font-semibold">Min Trading Days</td>
                  <td className="p-4 border text-center">None</td>
                  <td className="p-4 border text-center">None</td>
                  <td className="p-4 border text-center">None</td>
                </tr>
                <tr>
                  <td className="p-4 border font-semibold">Max Trading Period</td>
                  <td className="p-4 border text-center">60 Days</td>
                  <td className="p-4 border text-center">60 Days</td>
                  <td className="p-4 border text-center">Unlimited</td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="p-4 border font-semibold">Profit Split</td>
                  <td className="p-4 border text-center">-</td>
                  <td className="p-4 border text-center">-</td>
                  <td className="p-4 border text-center">80% You / 20% Us</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="mt-12 grid md:grid-cols-2 gap-8">
            <Card className="border-2 border-emerald-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-emerald-700">
                  <CheckCircle className="w-6 h-6" />
                  What You Can Do
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <span>Trade all major forex pairs</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <span>Trade gold, silver, and indices</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <span>Use Expert Advisors (EAs)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <span>Trade during news events</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <span>Hold positions overnight</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <span>Trade on weekends (crypto)</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-2 border-red-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-700">
                  <X className="w-6 h-6" />
                  Prohibited Actions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <X className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
                    <span>Copy trading from other accounts</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <X className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
                    <span>Hedging with other accounts</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <X className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
                    <span>High-frequency trading (HFT)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <X className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
                    <span>Arbitrage strategies</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <X className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
                    <span>Martingale strategies</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <X className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
                    <span>Trading on latency or data delays</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Payment Methods */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 max-w-4xl">
          <h2 className="text-3xl font-bold text-center mb-4">Payment Methods</h2>
          <p className="text-center text-gray-600 mb-12">We accept all major Nigerian payment methods</p>
          
          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-4xl mb-4">🏦</div>
                <h3 className="font-bold mb-2">Bank Transfer</h3>
                <p className="text-sm text-gray-600">All Nigerian banks supported via Paystack</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-4xl mb-4">💳</div>
                <h3 className="font-bold mb-2">Card Payment</h3>
                <p className="text-sm text-gray-600">Visa, Mastercard, and Verve cards</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-4xl mb-4">📱</div>
                <h3 className="font-bold mb-2">USSD</h3>
                <p className="text-sm text-gray-600">Pay with USSD code from your phone</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-br from-emerald-600 to-green-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Start Your Journey?</h2>
          <p className="text-xl mb-8 text-emerald-50 max-w-2xl mx-auto">
            Create your account and purchase a challenge today
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-emerald-700 hover:bg-emerald-50 px-8">
              <Link to="/register">Create Free Account</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white/10 px-8">
              <Link to="/contact">Contact Sales</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
