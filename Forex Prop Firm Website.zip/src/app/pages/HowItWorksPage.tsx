import { Link } from 'react-router';
import { UserPlus, CreditCard, TrendingUp, DollarSign, CheckCircle } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';

export default function HowItWorksPage() {
  const steps = [
    {
      icon: UserPlus,
      title: 'Create Your Account',
      description: 'Sign up for free in less than 2 minutes. No credit card required to register.',
      details: [
        'Fill in your basic information',
        'Verify your email address',
        'Complete your profile',
      ],
    },
    {
      icon: CreditCard,
      title: 'Choose & Buy Challenge',
      description: 'Select your preferred account size (Naira or Dollar) and pay the one-time challenge fee.',
      details: [
        'Pick between ₦50K to ₦500K (Naira)',
        'Or $5K to $50K (Dollar accounts)',
        'Pay securely with Paystack',
      ],
    },
    {
      icon: TrendingUp,
      title: 'Start Trading',
      description: 'Receive your MT5 credentials instantly and start trading to reach your profit target.',
      details: [
        'Login to MetaTrader 5',
        'Trade all major forex pairs',
        'Reach 100% profit target',
      ],
    },
    {
      icon: DollarSign,
      title: 'Get Paid',
      description: 'Once you pass the challenge, request payouts and receive 80% of your profits.',
      details: [
        'Request payout from dashboard',
        'Receive funds in 3-5 business days',
        'Keep trading and earning',
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-gradient-to-br from-emerald-600 to-green-700 text-white py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">How Noble Funded Works</h1>
          <p className="text-xl text-emerald-50 max-w-2xl mx-auto">
            From registration to your first payout in 4 simple steps
          </p>
        </div>
      </section>

      {/* Steps */}
      <section className="py-20">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="space-y-12">
            {steps.map((step, index) => (
              <div key={index} className="flex flex-col md:flex-row items-center gap-8">
                <div className="flex-shrink-0">
                  <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center relative">
                    <step.icon className="w-10 h-10 text-emerald-600" />
                    <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold">
                      {index + 1}
                    </div>
                  </div>
                </div>
                
                <Card className="flex-1 border-2 border-gray-200 hover:border-emerald-300 transition-colors">
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-bold mb-3">{step.title}</h3>
                    <p className="text-gray-600 mb-4 text-lg">{step.description}</p>
                    <ul className="space-y-2">
                      {step.details.map((detail, idx) => (
                        <li key={idx} className="flex items-center gap-2">
                          <CheckCircle className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                          <span className="text-gray-700">{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Video Section Placeholder */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-4xl">
          <h2 className="text-3xl font-bold text-center mb-12">Watch Our Tutorial</h2>
          <div className="aspect-video bg-gray-200 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <div className="text-6xl mb-4">🎥</div>
              <p className="text-gray-600">Video tutorial coming soon</p>
              <p className="text-sm text-gray-500 mt-2">Learn how to navigate the platform step by step</p>
            </div>
          </div>
        </div>
      </section>

      {/* Key Features */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 max-w-6xl">
          <h2 className="text-3xl font-bold text-center mb-12">Why Traders Choose Us</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-2 border-emerald-100">
              <CardContent className="p-6">
                <div className="text-4xl mb-4">⚡</div>
                <h3 className="text-xl font-bold mb-2">No Minimum Trading Days</h3>
                <p className="text-gray-600">
                  Pass your challenge in 1 day or 60 days - it's completely up to you. Trade at your own pace.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-emerald-100">
              <CardContent className="p-6">
                <div className="text-4xl mb-4">💰</div>
                <h3 className="text-xl font-bold mb-2">80% Profit Split</h3>
                <p className="text-gray-600">
                  Keep 80% of all profits you generate. One of the highest profit splits in the industry.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-emerald-100">
              <CardContent className="p-6">
                <div className="text-4xl mb-4">🇳🇬</div>
                <h3 className="text-xl font-bold mb-2">Local Payment Options</h3>
                <p className="text-gray-600">
                  Pay with your Nigerian bank account, card, or USSD. No international payment hassles.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-emerald-100">
              <CardContent className="p-6">
                <div className="text-4xl mb-4">🔒</div>
                <h3 className="text-xl font-bold mb-2">Clear & Fair Rules</h3>
                <p className="text-gray-600">
                  Transparent rules with no hidden catches. 10% max drawdown, 3% daily loss limit.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-emerald-100">
              <CardContent className="p-6">
                <div className="text-4xl mb-4">⏱️</div>
                <h3 className="text-xl font-bold mb-2">Fast Payouts</h3>
                <p className="text-gray-600">
                  Request your payout and receive funds in your Nigerian bank account within 3-5 business days.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-emerald-100">
              <CardContent className="p-6">
                <div className="text-4xl mb-4">📞</div>
                <h3 className="text-xl font-bold mb-2">Nigerian Support Team</h3>
                <p className="text-gray-600">
                  Get help from our local support team via WhatsApp, email, or phone during business hours.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-br from-emerald-600 to-green-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Get Started?</h2>
          <p className="text-xl mb-8 text-emerald-50 max-w-2xl mx-auto">
            Join Noble Funded today and start your journey to becoming a funded trader
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-emerald-700 hover:bg-emerald-50 px-8">
              <Link to="/register">Create Free Account</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white/10 px-8">
              <Link to="/pricing">View Pricing</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
