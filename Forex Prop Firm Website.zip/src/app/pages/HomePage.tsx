import { Link } from 'react-router';
import { TrendingUp, Shield, Zap, Users, CheckCircle, Star, ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '../components/ui/accordion';
import { getNairaPricingTiers, getDollarPricingTiers, getTestimonialsData, getFAQData } from '../data/mockData';

export default function HomePage() {
  const nairaPlans = getNairaPricingTiers();
  const dollarPlans = getDollarPricingTiers();
  const testimonials = getTestimonialsData();
  const faqs = getFAQData().slice(0, 6);

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-emerald-600 via-emerald-700 to-green-800 text-white overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi02LTIuNjg2LTYtNiAyLjY4Ni02IDYtNnoiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLW9wYWNpdHk9Ii4xIi8+PC9nPjwvc3ZnPg==')] opacity-10"></div>
        
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
              <span className="text-sm font-medium">🇳🇬 Proudly Nigerian</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Trade Forex With Our Capital,
              <span className="block text-emerald-200">Keep 80% of the Profits</span>
            </h1>
            
            <p className="text-xl md:text-2xl mb-8 text-emerald-50 max-w-2xl mx-auto">
              Nigeria's premier prop trading firm. Trade in Naira or Dollars with flexible rules and fast payouts.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button asChild size="lg" className="bg-white text-emerald-700 hover:bg-emerald-50 px-8 py-6 text-lg font-semibold">
                <Link to="/pricing">Get Funded Now</Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-2 border-white text-white hover:bg-white/10 px-8 py-6 text-lg font-semibold">
                <Link to="/how-it-works">How It Works</Link>
              </Button>
            </div>
            
            <div className="mt-12 flex flex-wrap justify-center gap-8 text-sm">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-200" />
                <span>No Minimum Trading Days</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-200" />
                <span>80% Profit Split</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-200" />
                <span>Fast Payouts (3-5 Days)</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Trade With Noble Funded?</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Built by Nigerian traders, for Nigerian traders. We understand the local market.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="border-2 border-emerald-100 hover:border-emerald-300 transition-colors">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                  <TrendingUp className="w-6 h-6 text-emerald-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Naira & Dollar Accounts</h3>
                <p className="text-gray-600">
                  Trade in your preferred currency. Naira accounts eliminate conversion hassles.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-2 border-emerald-100 hover:border-emerald-300 transition-colors">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-emerald-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Flexible Rules</h3>
                <p className="text-gray-600">
                  No minimum trading days. Trade at your own pace and reach targets faster.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-2 border-emerald-100 hover:border-emerald-300 transition-colors">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-emerald-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Transparent Process</h3>
                <p className="text-gray-600">
                  Clear rules, real-time tracking, and honest profit splits. No hidden fees.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-2 border-emerald-100 hover:border-emerald-300 transition-colors">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-emerald-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">Local Support</h3>
                <p className="text-gray-600">
                  Nigerian support team that understands your needs. WhatsApp, email, and phone support.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Comparison Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Choose Your Challenge</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Select between Naira or Dollar accounts based on your trading preference
            </p>
          </div>
          
          {/* Naira Plans */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold text-center mb-8 text-emerald-700">Naira Accounts (₦)</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {nairaPlans.map((plan) => (
                <Card key={plan.name} className={`relative ${plan.popular ? 'border-2 border-emerald-500 shadow-xl' : 'border border-gray-200'}`}>
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <span className="bg-emerald-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                        Most Popular
                      </span>
                    </div>
                  )}
                  <CardContent className="p-6">
                    <h4 className="text-xl font-bold mb-2">{plan.name}</h4>
                    <div className="mb-4">
                      <div className="text-3xl font-bold text-emerald-600">{plan.accountSize}</div>
                      <div className="text-gray-600">Account Size</div>
                    </div>
                    <div className="mb-6">
                      <div className="text-2xl font-bold">{plan.price}</div>
                      <div className="text-sm text-gray-600">One-time fee</div>
                    </div>
                    <ul className="space-y-2 mb-6">
                      {plan.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm">
                          <CheckCircle className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button asChild className="w-full bg-emerald-600 hover:bg-emerald-700">
                      <Link to="/pricing">Get Started</Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
          
          {/* Dollar Plans */}
          <div>
            <h3 className="text-2xl font-bold text-center mb-8 text-blue-700">Dollar Accounts ($)</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {dollarPlans.map((plan) => (
                <Card key={plan.name} className={`relative ${plan.popular ? 'border-2 border-blue-500 shadow-xl' : 'border border-gray-200'}`}>
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <span className="bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                        Most Popular
                      </span>
                    </div>
                  )}
                  <CardContent className="p-6">
                    <h4 className="text-xl font-bold mb-2">{plan.name}</h4>
                    <div className="mb-4">
                      <div className="text-3xl font-bold text-blue-600">{plan.accountSize}</div>
                      <div className="text-gray-600">Account Size</div>
                    </div>
                    <div className="mb-6">
                      <div className="text-2xl font-bold">{plan.price}</div>
                      <div className="text-sm text-gray-600">One-time fee</div>
                    </div>
                    <ul className="space-y-2 mb-6">
                      {plan.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm">
                          <CheckCircle className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                      <Link to="/pricing">Get Started</Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Traders Say</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Real stories from Nigerian traders who are making it happen
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {testimonials.map((testimonial) => (
              <Card key={testimonial.id} className="border border-gray-200">
                <CardContent className="p-6">
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-4 italic">"{testimonial.text}"</p>
                  <div className="border-t pt-4">
                    <div className="font-bold">{testimonial.name}</div>
                    <div className="text-sm text-gray-600">{testimonial.location}</div>
                    <div className="text-sm text-emerald-600 font-semibold mt-1">
                      {testimonial.achievement}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600">
              Got questions? We have answers.
            </p>
          </div>
          
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq) => (
              <AccordionItem key={faq.id} value={faq.id} className="border border-gray-200 rounded-lg px-6">
                <AccordionTrigger className="text-left hover:no-underline">
                  <span className="font-semibold">{faq.question}</span>
                </AccordionTrigger>
                <AccordionContent className="text-gray-600">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          
          <div className="text-center mt-8">
            <Button asChild variant="outline" size="lg">
              <Link to="/faq">
                View All FAQs
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-emerald-600 to-green-700 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">Ready to Get Funded?</h2>
          <p className="text-xl mb-8 text-emerald-50 max-w-2xl mx-auto">
            Join hundreds of Nigerian traders who are already trading with our capital
          </p>
          <Button asChild size="lg" className="bg-white text-emerald-700 hover:bg-emerald-50 px-8 py-6 text-lg font-semibold">
            <Link to="/register">Create Free Account</Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
