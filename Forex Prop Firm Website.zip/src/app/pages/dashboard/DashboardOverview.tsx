import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import { TrendingUp, TrendingDown, Trophy, DollarSign, Clock, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { getDashboardStats, getActiveChallenges } from '../../services/api';
import { Challenge } from '../../data/mockData';

export default function DashboardOverview() {
  const [stats, setStats] = useState<any>(null);
  const [activeChallenges, setActiveChallenges] = useState<Challenge[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  async function loadDashboardData() {
    try {
      const [statsData, challengesData] = await Promise.all([
        getDashboardStats(),
        getActiveChallenges(),
      ]);
      setStats(statsData);
      setActiveChallenges(challengesData);
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div>
        <h1 className="text-3xl font-bold mb-2">Dashboard Overview</h1>
        <p className="text-gray-600">Welcome back! Here's your trading summary.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-2 border-emerald-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Active Challenges</p>
                <p className="text-3xl font-bold">{stats.activeChallenges}</p>
              </div>
              <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center">
                <Trophy className="w-6 h-6 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Profit</p>
                <p className="text-3xl font-bold text-green-600">{stats.totalProfitFormatted}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Pending Payouts</p>
                <p className="text-3xl font-bold text-blue-600">{stats.upcomingPayouts}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Pass Rate</p>
                <p className="text-3xl font-bold text-purple-600">{stats.passRate}%</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Challenges Summary */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Active Challenges</h2>
          <Button asChild variant="outline">
            <Link to="/dashboard/challenges">
              View All
              <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </Button>
        </div>

        {activeChallenges.length > 0 ? (
          <div className="grid md:grid-cols-2 gap-6">
            {activeChallenges.map((challenge) => (
              <Card key={challenge.id} className="border-2 border-gray-200 hover:border-emerald-300 transition-colors">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">
                      Challenge #{challenge.id}
                    </CardTitle>
                    <span className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-sm font-semibold">
                      {challenge.status.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-2xl font-bold text-emerald-600">
                    {challenge.currency}{challenge.accountSize.toLocaleString()}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Current Balance</p>
                      <p className="text-xl font-bold">
                        {challenge.currency}{challenge.currentBalance.toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Profit</p>
                      <p className={`text-xl font-bold ${challenge.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {challenge.profit >= 0 ? '+' : ''}{challenge.currency}{challenge.profit.toLocaleString()}
                      </p>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-gray-600">Progress to Target</span>
                      <span className="font-semibold">{challenge.profitPercentage}%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-600 rounded-full transition-all"
                        style={{ width: `${Math.min(challenge.profitPercentage, 100)}%` }}
                      ></div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4" />
                      <span>{challenge.daysRemaining} days left</span>
                    </div>
                    <Button asChild size="sm" className="bg-emerald-600 hover:bg-emerald-700">
                      <Link to={`/dashboard/challenges/${challenge.id}`}>View Details</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="border-2 border-dashed border-gray-300">
            <CardContent className="p-12 text-center">
              <Trophy className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold mb-2">No Active Challenges</h3>
              <p className="text-gray-600 mb-6">
                Start your trading journey by purchasing a challenge
              </p>
              <Button asChild className="bg-emerald-600 hover:bg-emerald-700">
                <Link to="/pricing">Buy Challenge</Link>
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Recent Activity */}
      <div>
        <h2 className="text-2xl font-bold mb-6">Recent Activity</h2>
        <Card>
          <CardContent className="p-0">
            <div className="divide-y">
              {stats.recentActivity.map((activity: any) => (
                <div key={activity.id} className="p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0">
                        {activity.type === 'trade' && <TrendingUp className="w-5 h-5 text-emerald-600" />}
                        {activity.type === 'payout' && <DollarSign className="w-5 h-5 text-emerald-600" />}
                        {activity.type === 'challenge' && <Trophy className="w-5 h-5 text-emerald-600" />}
                        {activity.type === 'achievement' && <Trophy className="w-5 h-5 text-emerald-600" />}
                      </div>
                      <div>
                        <p className="font-medium">{activity.description}</p>
                        <p className="text-sm text-gray-600">{activity.timestamp}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-2xl font-bold mb-6">Quick Actions</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="border-2 border-gray-200 hover:border-emerald-300 transition-colors cursor-pointer">
            <Link to="/pricing">
              <CardContent className="p-6 text-center">
                <div className="text-4xl mb-4">🛒</div>
                <h3 className="font-bold mb-2">Buy New Challenge</h3>
                <p className="text-sm text-gray-600">Purchase a new trading challenge</p>
              </CardContent>
            </Link>
          </Card>

          <Card className="border-2 border-gray-200 hover:border-emerald-300 transition-colors cursor-pointer">
            <Link to="/dashboard/payouts">
              <CardContent className="p-6 text-center">
                <div className="text-4xl mb-4">💰</div>
                <h3 className="font-bold mb-2">Request Payout</h3>
                <p className="text-sm text-gray-600">Withdraw your earned profits</p>
              </CardContent>
            </Link>
          </Card>

          <Card className="border-2 border-gray-200 hover:border-emerald-300 transition-colors cursor-pointer">
            <Link to="/dashboard/support">
              <CardContent className="p-6 text-center">
                <div className="text-4xl mb-4">💬</div>
                <h3 className="font-bold mb-2">Contact Support</h3>
                <p className="text-sm text-gray-600">Get help from our team</p>
              </CardContent>
            </Link>
          </Card>
        </div>
      </div>
    </div>
  );
}
