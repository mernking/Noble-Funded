import { useEffect, useState } from 'react';
import { DollarSign, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../../components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { getPayouts, requestPayout, getActiveChallenges } from '../../services/api';
import { Payout } from '../../data/mockData';
import { toast } from 'sonner';

export default function PayoutsPage() {
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [loading, setLoading] = useState(true);
  const [showRequestDialog, setShowRequestDialog] = useState(false);
  const [requestForm, setRequestForm] = useState({
    challengeId: '',
    amount: '',
    accountName: '',
    accountNumber: '',
    bankName: '',
  });

  useEffect(() => {
    loadPayouts();
  }, []);

  async function loadPayouts() {
    try {
      const data = await getPayouts();
      setPayouts(data);
    } catch (error) {
      console.error('Failed to load payouts:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleRequestPayout = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      await requestPayout({
        challengeId: requestForm.challengeId,
        amount: parseFloat(requestForm.amount),
        bankDetails: {
          accountName: requestForm.accountName,
          accountNumber: requestForm.accountNumber,
          bankName: requestForm.bankName,
        },
      });
      
      toast.success('Payout request submitted successfully!');
      setShowRequestDialog(false);
      loadPayouts();
      setRequestForm({
        challengeId: '',
        amount: '',
        accountName: '',
        accountNumber: '',
        bankName: '',
      });
    } catch (error) {
      toast.error('Failed to submit payout request');
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'approved':
        return <CheckCircle className="w-5 h-5 text-blue-600" />;
      case 'rejected':
        return <XCircle className="w-5 h-5 text-red-600" />;
      default:
        return <Clock className="w-5 h-5 text-yellow-600" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      paid: 'bg-green-100 text-green-700',
      approved: 'bg-blue-100 text-blue-700',
      rejected: 'bg-red-100 text-red-700',
      pending: 'bg-yellow-100 text-yellow-700',
    };
    return <span className={`px-3 py-1 rounded-full text-sm font-semibold ${variants[status]}`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  const totalPaid = payouts.filter(p => p.status === 'paid').reduce((sum, p) => sum + p.amount, 0);
  const pendingAmount = payouts.filter(p => p.status === 'pending').reduce((sum, p) => sum + p.amount, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Payouts</h1>
          <p className="text-gray-600">Manage your profit withdrawals</p>
        </div>
        
        <Dialog open={showRequestDialog} onOpenChange={setShowRequestDialog}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <DollarSign className="mr-2 w-4 h-4" />
              Request Payout
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Request Payout</DialogTitle>
              <DialogDescription>
                Submit your payout request. Payouts are processed within 3-5 business days.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleRequestPayout} className="space-y-4">
              <div>
                <Label htmlFor="challengeId">Challenge ID *</Label>
                <Input
                  id="challengeId"
                  value={requestForm.challengeId}
                  onChange={(e) => setRequestForm({ ...requestForm, challengeId: e.target.value })}
                  required
                  placeholder="CH12345"
                  className="mt-2"
                />
              </div>
              
              <div>
                <Label htmlFor="amount">Amount *</Label>
                <Input
                  id="amount"
                  type="number"
                  value={requestForm.amount}
                  onChange={(e) => setRequestForm({ ...requestForm, amount: e.target.value })}
                  required
                  placeholder="Enter amount"
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="accountName">Account Name *</Label>
                <Input
                  id="accountName"
                  value={requestForm.accountName}
                  onChange={(e) => setRequestForm({ ...requestForm, accountName: e.target.value })}
                  required
                  placeholder="Your bank account name"
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="accountNumber">Account Number *</Label>
                <Input
                  id="accountNumber"
                  value={requestForm.accountNumber}
                  onChange={(e) => setRequestForm({ ...requestForm, accountNumber: e.target.value })}
                  required
                  placeholder="0123456789"
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="bankName">Bank Name *</Label>
                <Select value={requestForm.bankName} onValueChange={(value) => setRequestForm({ ...requestForm, bankName: value })}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select your bank" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Access Bank">Access Bank</SelectItem>
                    <SelectItem value="GTBank">GTBank</SelectItem>
                    <SelectItem value="First Bank">First Bank</SelectItem>
                    <SelectItem value="UBA">UBA</SelectItem>
                    <SelectItem value="Zenith Bank">Zenith Bank</SelectItem>
                    <SelectItem value="Ecobank">Ecobank</SelectItem>
                    <SelectItem value="Fidelity Bank">Fidelity Bank</SelectItem>
                    <SelectItem value="Union Bank">Union Bank</SelectItem>
                    <SelectItem value="Sterling Bank">Sterling Bank</SelectItem>
                    <SelectItem value="Stanbic IBTC">Stanbic IBTC</SelectItem>
                    <SelectItem value="Wema Bank">Wema Bank</SelectItem>
                    <SelectItem value="Polaris Bank">Polaris Bank</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="button" variant="outline" className="flex-1" onClick={() => setShowRequestDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="flex-1 bg-emerald-600 hover:bg-emerald-700">
                  Submit Request
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="border-2 border-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Paid</p>
                <p className="text-3xl font-bold text-green-600">₦{totalPaid.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-yellow-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Pending</p>
                <p className="text-3xl font-bold text-yellow-600">₦{pendingAmount.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2 border-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Requests</p>
                <p className="text-3xl font-bold text-blue-600">{payouts.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payouts List */}
      <Card>
        <CardHeader>
          <CardTitle>Payout History</CardTitle>
        </CardHeader>
        <CardContent>
          {payouts.length > 0 ? (
            <div className="space-y-4">
              {payouts.map((payout) => (
                <div key={payout.id} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="flex items-start gap-4 flex-1">
                      <div className="mt-1">
                        {getStatusIcon(payout.status)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-1">
                          <h3 className="font-bold">Payout #{payout.id}</h3>
                          {getStatusBadge(payout.status)}
                        </div>
                        <p className="text-sm text-gray-600 mb-2">
                          Challenge #{payout.challengeId}
                        </p>
                        {payout.bankDetails && (
                          <p className="text-sm text-gray-600">
                            {payout.bankDetails.bankName} - {payout.bankDetails.accountNumber}
                          </p>
                        )}
                        {payout.notes && (
                          <p className="text-sm text-gray-600 mt-1">
                            <AlertCircle className="w-4 h-4 inline mr-1" />
                            {payout.notes}
                          </p>
                        )}
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <p className="text-2xl font-bold text-emerald-600">
                        {payout.currency}{payout.amount.toLocaleString()}
                      </p>
                      <p className="text-sm text-gray-600 mt-1">
                        Requested: {new Date(payout.requestDate).toLocaleDateString()}
                      </p>
                      {payout.paidDate && (
                        <p className="text-sm text-gray-600">
                          Paid: {new Date(payout.paidDate).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-gray-600">
              <DollarSign className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-lg">No payout history yet</p>
              <p className="text-sm mt-2">Complete challenges to request your first payout</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
