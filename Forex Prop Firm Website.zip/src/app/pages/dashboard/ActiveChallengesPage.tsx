import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router';
import { ArrowLeft, Copy, Eye, EyeOff, Download, Clock, TrendingUp, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Progress } from '../../components/ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../components/ui/table';
import { getActiveChallenges, getTradingActivity } from '../../services/api';
import { Challenge, TradeHistory } from '../../data/mockData';
import { toast } from 'sonner';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function ActiveChallengesPage() {
  const { id } = useParams();
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [selectedChallenge, setSelectedChallenge] = useState<Challenge | null>(null);
  const [trades, setTrades] = useState<TradeHistory[]>([]);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadChallenges();
  }, []);

  useEffect(() => {
    if (id && challenges.length > 0) {
      const challenge = challenges.find(c => c.id === id);
      if (challenge) {
        setSelectedChallenge(challenge);
        loadTrades(id);
      }
    } else if (challenges.length > 0 && !id) {
      setSelectedChallenge(challenges[0]);
      loadTrades(challenges[0].id);
    }
  }, [id, challenges]);

  async function loadChallenges() {
    try {
      const data = await getActiveChallenges();
      setChallenges(data);
    } catch (error) {
      console.error('Failed to load challenges:', error);
    } finally {
      setLoading(false);
    }
  }

  async function loadTrades(challengeId: string) {
    try {
      const data = await getTradingActivity(challengeId);
      setTrades(data);
    } catch (error) {
      console.error('Failed to load trades:', error);
    }
  }

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard!`);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (challenges.length === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Active Challenges</h1>
          <p className="text-gray-600">Manage and track your trading challenges</p>
        </div>
        
        <Card className="border-2 border-dashed border-gray-300">
          <CardContent className="p-12 text-center">
            <div className="text-6xl mb-4">🏆</div>
            <h3 className="text-2xl font-bold mb-2">No Active Challenges</h3>
            <p className="text-gray-600 mb-6">
              You don't have any active challenges. Purchase one to start trading!
            </p>
            <Button asChild className="bg-emerald-600 hover:bg-emerald-700" size="lg">
              <Link to="/pricing">Buy Challenge</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Generate mock chart data
  const chartData = [
    { day: 'Day 1', balance: selectedChallenge?.startingBalance },
    { day: 'Day 7', balance: selectedChallenge ? selectedChallenge.startingBalance * 1.05 : 0 },
    { day: 'Day 14', balance: selectedChallenge ? selectedChallenge.startingBalance * 1.15 : 0 },
    { day: 'Day 21', balance: selectedChallenge ? selectedChallenge.startingBalance * 1.25 : 0 },
    { day: 'Day 28', balance: selectedChallenge ? selectedChallenge.startingBalance * 1.35 : 0 },
    { day: 'Today', balance: selectedChallenge?.currentBalance },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Active Challenges</h1>
          <p className="text-gray-600">Track your progress and manage your challenges</p>
        </div>
        {id && (
          <Button asChild variant="outline">
            <Link to="/dashboard/challenges">
              <ArrowLeft className="mr-2 w-4 h-4" />
              Back to All Challenges
            </Link>
          </Button>
        )}
      </div>

      {/* Challenge Selector (when viewing list) */}
      {!id && challenges.length > 1 && (
        <div className="flex gap-4 overflow-x-auto pb-4">
          {challenges.map((challenge) => (
            <Card
              key={challenge.id}
              className={`flex-shrink-0 w-64 cursor-pointer transition-all ${
                selectedChallenge?.id === challenge.id
                  ? 'border-2 border-emerald-500 shadow-lg'
                  : 'border border-gray-200 hover:border-emerald-300'
              }`}
              onClick={() => {
                setSelectedChallenge(challenge);
                loadTrades(challenge.id);
              }}
            >
              <CardContent className="p-4">
                <div className="font-bold mb-1">Challenge #{challenge.id}</div>
                <div className="text-2xl font-bold text-emerald-600">
                  {challenge.currency}{challenge.accountSize.toLocaleString()}
                </div>
                <div className="text-sm text-gray-600 mt-2">
                  {challenge.profitPercentage}% to target
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {selectedChallenge && (
        <>
          {/* Challenge Overview Card */}
          <Card className="border-2 border-emerald-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl">Challenge #{selectedChallenge.id}</CardTitle>
                  <div className="text-3xl font-bold text-emerald-600 mt-2">
                    {selectedChallenge.currency}{selectedChallenge.accountSize.toLocaleString()}
                  </div>
                </div>
                <div className="text-right">
                  <span className="px-4 py-2 bg-emerald-100 text-emerald-700 rounded-full text-sm font-semibold">
                    {selectedChallenge.status.toUpperCase()} - {selectedChallenge.phase}
                  </span>
                  <div className="flex items-center gap-2 text-gray-600 mt-2">
                    <Clock className="w-4 h-4" />
                    <span>{selectedChallenge.daysRemaining} days remaining</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Balance Info */}
              <div className="grid md:grid-cols-4 gap-6">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Starting Balance</p>
                  <p className="text-xl font-bold">
                    {selectedChallenge.currency}{selectedChallenge.startingBalance.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Current Balance</p>
                  <p className="text-xl font-bold">
                    {selectedChallenge.currency}{selectedChallenge.currentBalance.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Current Equity</p>
                  <p className="text-xl font-bold">
                    {selectedChallenge.currency}{selectedChallenge.currentEquity.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Profit/Loss</p>
                  <p className={`text-xl font-bold ${selectedChallenge.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {selectedChallenge.profit >= 0 ? '+' : ''}{selectedChallenge.currency}{selectedChallenge.profit.toLocaleString()}
                  </p>
                </div>
              </div>

              {/* Progress to Target */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold">Progress to Target</span>
                  <span className="text-emerald-600 font-bold">
                    {selectedChallenge.profitPercentage}% / {selectedChallenge.targetPercentage}%
                  </span>
                </div>
                <Progress value={selectedChallenge.profitPercentage} className="h-3" />
                <p className="text-sm text-gray-600 mt-2">
                  Target: {selectedChallenge.currency}{selectedChallenge.targetBalance.toLocaleString()}
                </p>
              </div>

              {/* Rules Compliance */}
              <div>
                <h3 className="font-bold mb-4">Rules Compliance</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className={`p-4 rounded-lg border-2 ${
                    selectedChallenge.maxDrawdown <= selectedChallenge.maxDrawdownLimit * 0.7
                      ? 'border-green-200 bg-green-50'
                      : selectedChallenge.maxDrawdown <= selectedChallenge.maxDrawdownLimit * 0.9
                      ? 'border-yellow-200 bg-yellow-50'
                      : 'border-red-200 bg-red-50'
                  }`}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold">Max Drawdown</span>
                      <span className={`font-bold ${
                        selectedChallenge.maxDrawdown <= selectedChallenge.maxDrawdownLimit * 0.7
                          ? 'text-green-600'
                          : selectedChallenge.maxDrawdown <= selectedChallenge.maxDrawdownLimit * 0.9
                          ? 'text-yellow-600'
                          : 'text-red-600'
                      }`}>
                        {selectedChallenge.maxDrawdown}% / {selectedChallenge.maxDrawdownLimit}%
                      </span>
                    </div>
                    <Progress
                      value={(selectedChallenge.maxDrawdown / selectedChallenge.maxDrawdownLimit) * 100}
                      className="h-2"
                    />
                  </div>

                  <div className={`p-4 rounded-lg border-2 ${
                    selectedChallenge.dailyLoss <= selectedChallenge.dailyLossLimit * 0.5
                      ? 'border-green-200 bg-green-50'
                      : selectedChallenge.dailyLoss <= selectedChallenge.dailyLossLimit * 0.8
                      ? 'border-yellow-200 bg-yellow-50'
                      : 'border-red-200 bg-red-50'
                  }`}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold">Daily Loss</span>
                      <span className={`font-bold ${
                        selectedChallenge.dailyLoss <= selectedChallenge.dailyLossLimit * 0.5
                          ? 'text-green-600'
                          : selectedChallenge.dailyLoss <= selectedChallenge.dailyLossLimit * 0.8
                          ? 'text-yellow-600'
                          : 'text-red-600'
                      }`}>
                        {selectedChallenge.dailyLoss}% / {selectedChallenge.dailyLossLimit}%
                      </span>
                    </div>
                    <Progress
                      value={(selectedChallenge.dailyLoss / selectedChallenge.dailyLossLimit) * 100}
                      className="h-2"
                    />
                  </div>
                </div>
              </div>

              {/* MT5 Credentials */}
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="font-bold mb-4">MT5 Trading Account</h3>
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Login ID</p>
                    <div className="flex items-center gap-2">
                      <p className="font-mono font-bold">{selectedChallenge.mt5Login}</p>
                      <button
                        onClick={() => copyToClipboard(selectedChallenge.mt5Login, 'Login ID')}
                        className="p-1 hover:bg-gray-200 rounded"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Server</p>
                    <div className="flex items-center gap-2">
                      <p className="font-mono font-bold">{selectedChallenge.mt5Server}</p>
                      <button
                        onClick={() => copyToClipboard(selectedChallenge.mt5Server, 'Server')}
                        className="p-1 hover:bg-gray-200 rounded"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Password</p>
                    <div className="flex items-center gap-2">
                      <p className="font-mono font-bold">
                        {showPassword ? selectedChallenge.mt5Password : '••••••••'}
                      </p>
                      <button
                        onClick={() => setShowPassword(!showPassword)}
                        className="p-1 hover:bg-gray-200 rounded"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => copyToClipboard(selectedChallenge.mt5Password, 'Password')}
                        className="p-1 hover:bg-gray-200 rounded"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t">
                  <Button variant="outline" size="sm">
                    <Download className="mr-2 w-4 h-4" />
                    Download MT5 Platform
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Equity Curve Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Equity Curve</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="balance" stroke="#059669" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Trade History */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Trades (Last 20)</CardTitle>
            </CardHeader>
            <CardContent>
              {trades.length > 0 ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Symbol</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Lot Size</TableHead>
                        <TableHead>Open Price</TableHead>
                        <TableHead>Close Price</TableHead>
                        <TableHead>Profit/Loss</TableHead>
                        <TableHead>Duration</TableHead>
                        <TableHead>Close Time</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {trades.map((trade) => (
                        <TableRow key={trade.id}>
                          <TableCell className="font-semibold">{trade.symbol}</TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded text-xs font-semibold ${
                              trade.type === 'buy' ? 'bg-blue-100 text-blue-700' : 'bg-orange-100 text-orange-700'
                            }`}>
                              {trade.type.toUpperCase()}
                            </span>
                          </TableCell>
                          <TableCell>{trade.lotSize}</TableCell>
                          <TableCell>{trade.openPrice}</TableCell>
                          <TableCell>{trade.closePrice}</TableCell>
                          <TableCell>
                            <span className={`font-bold ${trade.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {trade.profit >= 0 ? '+' : ''}{selectedChallenge.currency}{trade.profit.toLocaleString()}
                            </span>
                          </TableCell>
                          <TableCell>{trade.duration}</TableCell>
                          <TableCell className="text-sm text-gray-600">
                            {new Date(trade.closeTime).toLocaleString()}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-600">
                  No trades yet. Start trading to see your history here.
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
