import { useEffect, useState } from 'react';
import { Filter } from 'lucide-react';
import { Card, CardContent } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Button } from '../../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { getChallengeHistory } from '../../services/api';
import { Challenge } from '../../data/mockData';

export default function ChallengeHistoryPage() {
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [filter, setFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  async function loadHistory() {
    try {
      const data = await getChallengeHistory();
      setChallenges(data);
    } catch (error) {
      console.error('Failed to load history:', error);
    } finally {
      setLoading(false);
    }
  }

  const filteredChallenges = filter === 'all'
    ? challenges
    : challenges.filter(c => c.status === filter);

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { color: string; text: string }> = {
      active: { color: 'bg-blue-100 text-blue-700', text: '⏳ In Progress' },
      passed: { color: 'bg-green-100 text-green-700', text: '✅ Passed' },
      failed: { color: 'bg-red-100 text-red-700', text: '❌ Failed' },
    };
    const variant = variants[status] || variants.active;
    return <span className={`px-3 py-1 rounded-full text-sm font-semibold ${variant.color}`}>{variant.text}</span>;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Challenge History</h1>
        <p className="text-gray-600">View all your past and current challenges</p>
      </div>

      {/* Filter */}
      <div className="flex items-center gap-4">
        <Filter className="w-5 h-5 text-gray-600" />
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Challenges</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="passed">Passed</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Challenges List */}
      <div className="space-y-4">
        {filteredChallenges.map((challenge) => (
          <Card key={challenge.id} className="border-2 border-gray-200">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-xl font-bold">Challenge #{challenge.id}</h3>
                    {getStatusBadge(challenge.status)}
                  </div>
                  
                  <div className="grid md:grid-cols-4 gap-4 mt-4">
                    <div>
                      <p className="text-sm text-gray-600">Account Size</p>
                      <p className="text-lg font-bold text-emerald-600">
                        {challenge.currency}{challenge.accountSize.toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Final Balance</p>
                      <p className="text-lg font-bold">
                        {challenge.currency}{challenge.currentBalance.toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Profit/Loss</p>
                      <p className={`text-lg font-bold ${challenge.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {challenge.profit >= 0 ? '+' : ''}{challenge.currency}{challenge.profit.toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Performance</p>
                      <p className={`text-lg font-bold ${challenge.profitPercentage >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {challenge.profitPercentage >= 0 ? '+' : ''}{challenge.profitPercentage}%
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-6 mt-4 text-sm text-gray-600">
                    <span>Start: {new Date(challenge.startDate).toLocaleDateString()}</span>
                    {challenge.endDate && (
                      <span>End: {new Date(challenge.endDate).toLocaleDateString()}</span>
                    )}
                    <span>Phase: {challenge.phase}</span>
                  </div>
                </div>

                {challenge.status === 'passed' && (
                  <Button variant="outline">View Certificate</Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredChallenges.length === 0 && (
        <Card className="border-2 border-dashed border-gray-300">
          <CardContent className="p-12 text-center">
            <p className="text-gray-600 text-lg">No challenges found</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
